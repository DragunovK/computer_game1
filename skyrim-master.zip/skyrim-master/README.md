# skyrim
kursach
add weapon(skyrim)
